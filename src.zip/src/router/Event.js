import Vue from 'vue';
import Router from 'vue-router';

// Import your Vue components
import Home from '@/components/Home.vue';
import Albums from '@/components/Albums.vue';
import Events from '@/components/Events.vue';
import Blog from '@/components/Blog.vue';
import Contact from '@/components/Contact.vue';
import Login from '@/components/Login.vue';

Vue.use(Router);

export default new Router({
  routes: [
    { path: '/', component: Home },
    { path: '/albums', component: Albums },
    { path: '/events', component: Events },
    { path: '/blog', component: Blog },
    { path: '/contact', component: Contact },
    { path: '/login', component: Login }
  ]
});
