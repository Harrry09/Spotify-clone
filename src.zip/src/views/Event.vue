<template>
  <div>
    <!-- Preloader -->
    <div v-if="isLoading" class="preloader d-flex align-items-center justify-content-center">
        <div class="lds-ellipsis">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>

    <!-- Header Area -->
    <header class="header-area">
        <!-- Navbar Area -->
        <div class="oneMusic-main-menu">
            <div class="classy-nav-container breakpoint-off">
                <div class="container">
                    <nav class="classy-navbar justify-content-between" id="oneMusicNav">
                        <!-- Nav brand -->
                        <router-link to="/" class="nav-brand"><img src="img/core-img/logo.png" alt=""></router-link>

                        <!-- Navbar Toggler -->
                        <div class="classy-navbar-toggler" @click="toggleMenu">
                            <span class="navbarToggler"><span></span><span></span><span></span></span>
                        </div>

                        <!-- Menu -->
                        <div class="classy-menu" :class="{ 'menu-on': isMenuOpen }">
                            <!-- Close Button -->
                            <div class="classycloseIcon" @click="toggleMenu">
                                <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                            </div>

                            <!-- Nav Start -->
                            <div class="classynav">
                                <ul>
                                    <li><router-link to="/">Home</router-link></li>
                                    <li><router-link to="/albums">Albums</router-link></li>
                                    <li><a href="#">Pages</a></li>
                                    <li><a href="#">Even Dropdown</a></li>
                                    <li><router-link to="/events">Events</router-link></li>
                                    <li><router-link to="/blog">News</router-link></li>
                                    <li><router-link to="/contact">Contact</router-link></li>
                                    <!-- Login/Register & Cart Button -->
                                    <div class="login-register-cart-button d-flex align-items-center">
                                        <!-- Login/Register -->
                                        <div class="login-register-btn mr-50">
                                            <router-link to="/login" id="loginBtn">Login / Register</router-link>
                                        </div>
                                    </div>
                                </ul>
                            </div>
                            <!-- Nav End -->
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content Areas (Breadcrumbs, Events, Newsletter, Testimonials, Contact) -->
    <router-view></router-view>

    <!-- Footer Area -->
    <footer class="footer-area">
        <div class="container">
            <div class="row d-flex flex-wrap align-items-center">
                <div class="col-12 col-md-6">
                    <a href="#"><img src="img/core-img/logo.png" alt=""></a>
                    <p class="copywrite-text">Copyright &copy; {{ currentYear }} All rights reserved | 
                        This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by 
                        <a href="https://colorlib.com" target="_blank">Colorlib</a>
                    </p>
                </div>

                <div class="col-12 col-md-6">
                    <div class="footer-nav">
                        <ul>
                            <li><router-link to="/">Home</router-link></li>
                            <li><router-link to="/albums">Albums</router-link></li>
                            <li><router-link to="/events">Events</router-link></li>
                            <li><router-link to="/blog">News</router-link></li>
                            <li><router-link to="/contact">Contact</router-link></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>
  </div>
</template>

<script>
export default {
  data() {
    return {
      isMenuOpen: false,
      isLoading: true
    };
  },
  computed: {
    currentYear() {
      return new Date().getFullYear();
    }
  },
  methods: {
    toggleMenu() {
      this.isMenuOpen = !this.isMenuOpen;
    }
  },
  mounted() {
    // Simulate preloader delay (remove this in production)
    setTimeout(() => {
      this.isLoading = false;
    }, 1000); // Adjust delay as necessary
  }
};
</script>

<style scoped>
/* Add your custom styles here or import CSS files */
</style>
